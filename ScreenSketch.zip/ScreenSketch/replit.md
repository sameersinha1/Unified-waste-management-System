# Cyber City Waste Management System

## Overview

A mobile-first waste management application designed for smart city infrastructure. The system connects citizens, field staff, and administrators through gamified waste collection, QR code scanning, and real-time tracking. Citizens earn points by scanning waste kiosks, field staff manage collection routes through QR bin scanning, and administrators oversee operations through comprehensive dashboards.

The application features role-based interfaces with distinct user flows: citizens interact through a gamified points system with scanning capabilities, field staff use route management and collection logging tools, and administrators access system-wide analytics and management features.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

**Frontend Framework**: React 18 with TypeScript running in a mobile-first responsive design. The application uses Wouter for client-side routing with a single-page architecture centered around the main MobileApp component.

**Component Architecture**: Built on shadcn/ui component library with Radix UI primitives, using Tailwind CSS for styling with a custom design system. Components are organized by role-based interfaces (citizen, field staff, admin) with shared UI elements and modular design patterns.

**Backend Framework**: Express.js server with TypeScript, implementing session-based authentication using express-session with PostgreSQL session storage. The server follows a RESTful API pattern with role-based middleware protection.

**Database Layer**: PostgreSQL database managed through Drizzle ORM with connection pooling via Neon serverless. The schema includes users with role-based access, waste bins with QR codes, collection logs, scan logs for citizen points, issue reporting, and route management tables.

**Authentication System**: Session-based authentication with bcrypt password hashing, CSRF protection, and role-based authorization middleware (citizen, field_staff, admin). Rate limiting is implemented for sensitive operations like login attempts and QR scanning.

**State Management**: TanStack Query (React Query) for server state management with custom API client handling authentication and error states. Local state managed through React hooks with context providers for global UI state.

**Mobile Optimization**: Progressive Web App (PWA) configuration with viewport meta tags, touch-optimized interfaces, and mobile-specific navigation patterns. The design system follows mobile-first principles with responsive breakpoints.

**Development Tools**: Vite for build tooling with hot module replacement, TypeScript for type safety, and custom development middleware for enhanced debugging in Replit environment.

## External Dependencies

**Database Service**: Neon PostgreSQL serverless database with connection pooling and WebSocket support for real-time features.

**UI Component Library**: Radix UI primitives for accessible component foundations, integrated through shadcn/ui component system with customizable styling.

**Styling Framework**: Tailwind CSS with custom theme configuration, including design tokens for colors, spacing, and typography aligned with the cyber city branding.

**Authentication Dependencies**: bcryptjs for password hashing, connect-pg-simple for PostgreSQL session storage, with express-rate-limit for protecting authentication endpoints.

**Development Environment**: Replit-specific tooling including cartographer plugin for development mode and runtime error overlay for enhanced debugging experience.

**Font Resources**: Google Fonts integration for Inter typography with additional font families (Architects Daughter, DM Sans, Fira Code, Geist Mono) loaded via CDN.

**Build and Deployment**: ESBuild for server bundling, Vite for client-side building, with production-ready configurations for both development and production environments.
import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table with role-based access
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  identifier: text("identifier").notNull().unique(), // Phone number, employee ID, etc.
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(), // citizen, field_staff, admin
  points: integer("points").default(0),
  employeeId: text("employee_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Waste collection points/bins
export const wasteBins = pgTable("waste_bins", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  qrCode: text("qr_code").notNull().unique(),
  location: text("location").notNull(),
  type: text("type").notNull(), // mixed, recyclable, organic
  status: text("status").default("active"), // active, full, maintenance
  lastCollection: timestamp("last_collection"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Collection logs
export const collectionLogs = pgTable("collection_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  binId: varchar("bin_id").references(() => wasteBins.id),
  employeeId: varchar("employee_id").references(() => users.id),
  collectedAt: timestamp("collected_at").defaultNow(),
  wasteAmount: integer("waste_amount"), // kg
  notes: text("notes"),
});

// Citizen scan logs for points
export const scanLogs = pgTable("scan_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  qrCode: text("qr_code").notNull(),
  pointsEarned: integer("points_earned").notNull(),
  scannedAt: timestamp("scanned_at").defaultNow(),
});

// Issue reports
export const issueReports = pgTable("issue_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  reporterId: varchar("reporter_id").references(() => users.id),
  assignedTo: varchar("assigned_to").references(() => users.id),
  type: text("type").notNull(), // overflowing_bin, damaged_bin, etc.
  description: text("description").notNull(),
  location: text("location").notNull(),
  status: text("status").default("open"), // open, in_progress, resolved
  photoUrl: text("photo_url"),
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

// Employee routes and tasks
export const routes = pgTable("routes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  assignedTo: varchar("assigned_to").references(() => users.id),
  date: timestamp("date").notNull(),
  status: text("status").default("pending"), // pending, in_progress, completed
  completedBins: integer("completed_bins").default(0),
  totalBins: integer("total_bins").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  identifier: true,
  password: true,
  name: true,
  role: true,
  employeeId: true,
});

export const insertWasteBinSchema = createInsertSchema(wasteBins).pick({
  qrCode: true,
  location: true,
  type: true,
});

export const insertCollectionLogSchema = createInsertSchema(collectionLogs).pick({
  binId: true,
  employeeId: true,
  wasteAmount: true,
  notes: true,
});

export const insertScanLogSchema = createInsertSchema(scanLogs).pick({
  userId: true,
  qrCode: true,
  pointsEarned: true,
});

export const insertIssueReportSchema = createInsertSchema(issueReports).pick({
  reporterId: true,
  type: true,
  description: true,
  location: true,
  photoUrl: true,
});

export const insertRouteSchema = createInsertSchema(routes).pick({
  name: true,
  assignedTo: true,
  date: true,
  totalBins: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type WasteBin = typeof wasteBins.$inferSelect;
export type CollectionLog = typeof collectionLogs.$inferSelect;
export type ScanLog = typeof scanLogs.$inferSelect;
export type IssueReport = typeof issueReports.$inferSelect;
export type Route = typeof routes.$inferSelect;

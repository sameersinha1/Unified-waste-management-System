const API_BASE = '';

interface ApiResponse<T> {
  data?: T;
  error?: string;
  message?: string;
}

export class ApiClient {
  private async request<T>(
    endpoint: string, 
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    try {
      const response = await fetch(`${API_BASE}${endpoint}`, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        credentials: 'include', // Include cookies for session management
        ...options,
      });

      const data = await response.json();

      if (!response.ok) {
        return { error: data.error || 'Request failed' };
      }

      return { data, message: data.message };
    } catch (error) {
      console.error('API request failed:', error);
      return { error: 'Network error' };
    }
  }

  // Authentication
  async login(identifier: string, password: string) {
    return this.request<{ user: any }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password }),
    });
  }

  async register(userData: {
    identifier: string;
    password: string;
    name: string;
    role: string;
    employeeId?: string;
  }) {
    return this.request<{ user: any }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  // Scanning
  async scanForPoints(qrCode: string) {
    return this.request<{ pointsEarned: number; totalPoints: number }>('/api/scan', {
      method: 'POST',
      body: JSON.stringify({ qrCode }),
    });
  }

  async logCollection(qrCode: string, wasteAmount?: number, notes?: string) {
    return this.request<{ collectionLog: any }>('/api/collect', {
      method: 'POST',
      body: JSON.stringify({ qrCode, wasteAmount, notes }),
    });
  }

  // Issue reporting
  async reportIssue(issue: {
    type: string;
    description: string;
    location: string;
    photoUrl?: string;
  }) {
    return this.request<{ issueReport: any }>('/api/issues', {
      method: 'POST',
      body: JSON.stringify(issue),
    });
  }

  // Logout
  async logout() {
    return this.request<{ message: string }>('/api/auth/logout', {
      method: 'POST',
    });
  }

  // User data
  async getUser(id: string) {
    return this.request<{ user: any }>(`/api/users/${id}`);
  }

  async getEmployeeCollections(id: string) {
    return this.request<{ collections: any[]; count: number }>(`/api/employees/${id}/collections`);
  }

  async getIssues() {
    return this.request<{ issues: any[] }>('/api/issues');
  }
}

export const api = new ApiClient();
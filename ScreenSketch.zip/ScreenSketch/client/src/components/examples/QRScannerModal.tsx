import { useState } from 'react';
import QRScannerModal from '../QRScannerModal';
import { Button } from '@/components/ui/button';

export default function QRScannerModalExample() {
  const [isOpen, setIsOpen] = useState(false);
  
  const handleScanSuccess = (data: string) => {
    console.log('Scanned:', data);
    setIsOpen(false);
  };
  
  return (
    <div className="p-4">
      <Button onClick={() => setIsOpen(true)}>
        Open Scanner
      </Button>
      
      <QRScannerModal 
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onScanSuccess={handleScanSuccess}
        userRole="citizen"
      />
    </div>
  );
}
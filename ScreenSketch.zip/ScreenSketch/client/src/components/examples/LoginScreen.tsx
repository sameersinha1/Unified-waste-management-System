import LoginScreen from '../LoginScreen';

export default function LoginScreenExample() {
  const handleLogin = (credentials: { identifier: string; password: string; role: string }) => {
    console.log('Login attempt:', credentials);
  };
  
  return <LoginScreen onLogin={handleLogin} />;
}
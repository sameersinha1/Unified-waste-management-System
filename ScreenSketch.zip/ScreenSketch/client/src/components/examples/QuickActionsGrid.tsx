import QuickActionsGrid from '../QuickActionsGrid';

export default function QuickActionsGridExample() {
  const handleActionClick = (action: string) => {
    console.log('Action clicked:', action);
  };
  
  return <QuickActionsGrid userRole="citizen" onActionClick={handleActionClick} />;
}
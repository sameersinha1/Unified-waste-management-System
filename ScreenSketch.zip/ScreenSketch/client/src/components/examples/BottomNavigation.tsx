import { useState } from 'react';
import BottomNavigation from '../BottomNavigation';

export default function BottomNavigationExample() {
  const [activeTab, setActiveTab] = useState('home');
  
  return <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} userRole="citizen" />;
}
import { useState } from 'react';
import ReportIssueModal from '../ReportIssueModal';
import { Button } from '@/components/ui/button';

export default function ReportIssueModalExample() {
  const [isOpen, setIsOpen] = useState(false);
  
  const handleSubmit = (issue: { type: string; description: string; location: string; photo?: File }) => {
    console.log('Issue submitted:', issue);
    setIsOpen(false);
  };
  
  return (
    <div className="p-4">
      <Button onClick={() => setIsOpen(true)}>
        Report Issue
      </Button>
      
      <ReportIssueModal 
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onSubmit={handleSubmit}
      />
    </div>
  );
}
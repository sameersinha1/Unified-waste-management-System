import EmployeeHomeScreen from '../EmployeeHomeScreen';

export default function EmployeeHomeScreenExample() {
  const handleActionClick = (action: string) => {
    console.log('Employee action clicked:', action);
  };
  
  return (
    <EmployeeHomeScreen 
      employeeName="John Smith"
      employeeId="EMP001"
      onActionClick={handleActionClick}
    />
  );
}
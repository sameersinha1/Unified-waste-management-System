import TipsUpdatesSection from '../TipsUpdatesSection';

export default function TipsUpdatesSectionExample() {
  const mockItems = [
    {
      id: '1',
      type: 'tip' as const,
      title: 'Recycling Tip',
      description: 'Clean plastic containers before disposal to improve recycling efficiency and earn bonus points!',
      isNew: false
    },
    {
      id: '2',
      type: 'update' as const,
      title: 'System Update',
      description: 'New QR code kiosks installed at Central Park and City Mall. Start earning points today!',
      isNew: true
    },
    {
      id: '3',
      type: 'reward' as const,
      title: 'Reward Alert',
      description: 'You\'re only 250 points away from a free movie ticket! Keep scanning to reach your goal.',
      isNew: false
    }
  ];
  
  return <TipsUpdatesSection items={mockItems} />;
}
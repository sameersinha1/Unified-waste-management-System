import MobileApp from '../MobileApp';

export default function MobileAppExample() {
  return <MobileApp />;
}
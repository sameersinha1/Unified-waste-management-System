import NextPickupCard from '../NextPickupCard';

export default function NextPickupCardExample() {
  return <NextPickupCard 
    date="Tomorrow" 
    time="8:00 AM" 
    wasteType="Mixed Waste Collection" 
    status="scheduled" 
  />;
}
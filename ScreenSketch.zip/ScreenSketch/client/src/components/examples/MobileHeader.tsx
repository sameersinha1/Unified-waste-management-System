import MobileHeader from '../MobileHeader';

export default function MobileHeaderExample() {
  return <MobileHeader userName="Demo User" points={850} userRole="citizen" />;
}
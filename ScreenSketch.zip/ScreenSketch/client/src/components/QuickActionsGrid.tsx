import { QrCode, AlertTriangle, MapPin, Gift } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface QuickActionsGridProps {
  userRole: 'citizen' | 'field_staff' | 'admin';
  onActionClick: (action: string) => void;
}

export default function QuickActionsGrid({ userRole, onActionClick }: QuickActionsGridProps) {
  const citizenActions = [
    {
      id: 'scan_waste',
      icon: QrCode,
      title: 'Scan Waste to Earn',
      subtitle: 'Scan QR codes at kiosks',
      bgColor: 'bg-chart-4',
      textColor: 'text-white'
    },
    {
      id: 'report_issue',
      icon: AlertTriangle,
      title: 'Report an Issue',
      subtitle: 'Report problems in your area',
      bgColor: 'bg-chart-3',
      textColor: 'text-white'
    },
    {
      id: 'find_kiosks',
      icon: MapPin,
      title: 'Find Kiosks',
      subtitle: 'Locate nearby waste stations',
      bgColor: 'bg-chart-2',
      textColor: 'text-white'
    },
    {
      id: 'rewards',
      icon: Gift,
      title: 'Redeem Rewards',
      subtitle: 'Use your earned points',
      bgColor: 'bg-chart-5',
      textColor: 'text-white'
    }
  ];

  const fieldStaffActions = [
    {
      id: 'scan_bin',
      icon: QrCode,
      title: 'Scan Bin',
      subtitle: 'Log bin collection',
      bgColor: 'bg-primary',
      textColor: 'text-primary-foreground'
    },
    {
      id: 'report_issue',
      icon: AlertTriangle,
      title: 'Report Issue',
      subtitle: 'Report equipment problems',
      bgColor: 'bg-chart-3',
      textColor: 'text-white'
    },
    {
      id: 'view_route',
      icon: MapPin,
      title: 'View Route',
      subtitle: 'Check today\'s collection route',
      bgColor: 'bg-chart-2',
      textColor: 'text-white'
    }
  ];

  const adminActions = [
    {
      id: 'manage_routes',
      icon: MapPin,
      title: 'Manage Routes',
      subtitle: 'Optimize collection routes',
      bgColor: 'bg-primary',
      textColor: 'text-primary-foreground'
    },
    {
      id: 'view_analytics',
      icon: Gift,
      title: 'Analytics',
      subtitle: 'View system performance',
      bgColor: 'bg-chart-2',
      textColor: 'text-white'
    }
  ];

  const getActions = () => {
    switch (userRole) {
      case 'citizen': return citizenActions;
      case 'field_staff': return fieldStaffActions;
      case 'admin': return adminActions;
    }
  };

  const actions = getActions();

  return (
    <div className="space-y-3">
      <h3 className="font-semibold text-lg px-4">Quick Actions</h3>
      
      <div className="grid grid-cols-2 gap-3 px-4">
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <Card 
              key={action.id}
              className={`${action.bgColor} ${action.textColor} border-0 hover-elevate cursor-pointer`}
              onClick={() => onActionClick(action.id)}
            >
              <CardContent className="p-4">
                <div className="space-y-2">
                  <Icon className="w-6 h-6" />
                  <div>
                    <h4 className="font-medium text-sm">{action.title}</h4>
                    <p className={`text-xs opacity-90`}>{action.subtitle}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
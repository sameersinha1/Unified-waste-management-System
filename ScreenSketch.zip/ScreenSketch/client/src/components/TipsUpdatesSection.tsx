import { Lightbulb, Bell, CheckCircle, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface TipUpdate {
  id: string;
  type: 'tip' | 'update' | 'alert' | 'reward';
  title: string;
  description: string;
  isNew?: boolean;
}

interface TipsUpdatesSectionProps {
  items: TipUpdate[];
}

export default function TipsUpdatesSection({ items }: TipsUpdatesSectionProps) {
  const getIcon = (type: string) => {
    switch (type) {
      case 'tip': return Lightbulb;
      case 'update': return Bell;
      case 'alert': return Bell;
      case 'reward': return Star;
      default: return Bell;
    }
  };

  const getColor = (type: string) => {
    switch (type) {
      case 'tip': return 'text-chart-2';
      case 'update': return 'text-chart-4';
      case 'alert': return 'text-chart-5';
      case 'reward': return 'text-chart-3';
    }
  };

  const getBgColor = (type: string) => {
    switch (type) {
      case 'tip': return 'bg-chart-2/10';
      case 'update': return 'bg-chart-4/10';
      case 'alert': return 'bg-chart-5/10';
      case 'reward': return 'bg-chart-3/10';
    }
  };

  return (
    <div className="space-y-3">
      <h3 className="font-semibold text-lg px-4">Tips & Updates</h3>
      
      <div className="space-y-3 px-4">
        {items.map((item) => {
          const Icon = getIcon(item.type);
          return (
            <Card key={item.id} className="border-card-border">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-full ${getBgColor(item.type)} flex items-center justify-center flex-shrink-0`}>
                    <Icon className={`w-4 h-4 ${getColor(item.type)}`} />
                  </div>
                  
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium text-sm">{item.title}</h4>
                      {item.isNew && (
                        <Badge variant="secondary" className="text-xs px-2 py-0">
                          New
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
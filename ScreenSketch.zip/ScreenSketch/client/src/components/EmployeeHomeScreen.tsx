import { Clock, MapPin, CheckCircle, AlertTriangle, Truck, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface EmployeeHomeScreenProps {
  employeeName: string;
  employeeId: string;
  onActionClick: (action: string) => void;
}

export default function EmployeeHomeScreen({ employeeName, employeeId, onActionClick }: EmployeeHomeScreenProps) {
  // Mock data for employee dashboard - todo: remove mock functionality
  const todayStats = {
    routesCompleted: 8,
    totalRoutes: 12,
    binsCollected: 47,
    issuesReported: 2
  };

  const currentShift = {
    startTime: "06:00 AM",
    endTime: "02:00 PM",
    status: "active",
    remainingHours: "4h 30m"
  };

  const priorityTasks = [
    {
      id: "1",
      type: "collection",
      location: "Central Park Area",
      priority: "high",
      deadline: "11:00 AM",
      status: "pending"
    },
    {
      id: "2", 
      type: "maintenance",
      location: "Bin #CP-045",
      priority: "medium",
      deadline: "01:00 PM",
      status: "in_progress"
    },
    {
      id: "3",
      type: "inspection",
      location: "City Mall Kiosks",
      priority: "low",
      deadline: "03:00 PM", 
      status: "pending"
    }
  ];

  const getTaskIcon = (type: string) => {
    switch (type) {
      case 'collection': return Truck;
      case 'maintenance': return AlertTriangle;
      case 'inspection': return CheckCircle;
      default: return MapPin;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-chart-5 text-white';
      case 'medium': return 'bg-chart-3 text-white'; 
      case 'low': return 'bg-chart-2 text-white';
      default: return 'bg-secondary text-secondary-foreground';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-secondary text-secondary-foreground';
      case 'in_progress': return 'bg-chart-3 text-white';
      case 'completed': return 'bg-chart-4 text-white';
      default: return 'bg-secondary text-secondary-foreground';
    }
  };

  return (
    <div className="space-y-4 pb-4">
      {/* Shift Status Card */}
      <div className="px-4">
        <Card className="bg-primary text-primary-foreground border-0">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="font-semibold">Current Shift</h3>
                <p className="text-sm text-primary-foreground/80">{employeeId}</p>
              </div>
              <Badge className="bg-chart-4 text-white">
                Active
              </Badge>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-primary-foreground/80">Shift Time</p>
                <p className="font-medium">{currentShift.startTime} - {currentShift.endTime}</p>
              </div>
              <div>
                <p className="text-primary-foreground/80">Remaining</p>
                <p className="font-medium">{currentShift.remainingHours}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today's Progress */}
      <div className="px-4">
        <h3 className="font-semibold text-lg mb-3">Today's Progress</h3>
        <div className="grid grid-cols-2 gap-3">
          <Card>
            <CardContent className="p-3 text-center">
              <div className="flex items-center justify-center w-8 h-8 bg-chart-4/10 rounded-full mx-auto mb-2">
                <CheckCircle className="w-4 h-4 text-chart-4" />
              </div>
              <p className="text-sm text-muted-foreground">Routes</p>
              <p className="font-bold text-lg">{todayStats.routesCompleted}/{todayStats.totalRoutes}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-3 text-center">
              <div className="flex items-center justify-center w-8 h-8 bg-primary/10 rounded-full mx-auto mb-2">
                <Truck className="w-4 h-4 text-primary" />
              </div>
              <p className="text-sm text-muted-foreground">Bins Collected</p>
              <p className="font-bold text-lg">{todayStats.binsCollected}</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Priority Tasks */}
      <div className="px-4">
        <h3 className="font-semibold text-lg mb-3">Priority Tasks</h3>
        <div className="space-y-3">
          {priorityTasks.map((task) => {
            const TaskIcon = getTaskIcon(task.type);
            return (
              <Card key={task.id} className="border-card-border">
                <CardContent className="p-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                      <TaskIcon className="w-4 h-4 text-muted-foreground" />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium text-sm">{task.location}</h4>
                        <Badge className={getPriorityColor(task.priority)} variant="secondary">
                          {task.priority}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {task.deadline}
                        </span>
                        <Badge className={getStatusColor(task.status)} variant="outline">
                          {task.status.replace('_', ' ')}
                        </Badge>
                      </div>
                    </div>
                    
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => onActionClick(`task_${task.id}`)}
                      data-testid={`button-task-${task.id}`}
                    >
                      View
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Quick Employee Actions */}
      <div className="px-4">
        <h3 className="font-semibold text-lg mb-3">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-3">
          <Button 
            className="h-auto py-3 bg-chart-4 hover:bg-chart-4/90 text-white"
            onClick={() => onActionClick('scan_collection')}
            data-testid="button-scan-collection"
          >
            <div className="flex flex-col items-center gap-1">
              <CheckCircle className="w-5 h-5" />
              <span className="text-sm">Log Collection</span>
            </div>
          </Button>
          
          <Button 
            className="h-auto py-3 bg-chart-2 hover:bg-chart-2/90 text-white"
            onClick={() => onActionClick('view_route')}
            data-testid="button-view-route"
          >
            <div className="flex flex-col items-center gap-1">
              <MapPin className="w-5 h-5" />
              <span className="text-sm">View Route</span>
            </div>
          </Button>
          
          <Button 
            className="h-auto py-3 bg-chart-3 hover:bg-chart-3/90 text-white"
            onClick={() => onActionClick('report_maintenance')}
            data-testid="button-report-maintenance"
          >
            <div className="flex flex-col items-center gap-1">
              <AlertTriangle className="w-5 h-5" />
              <span className="text-sm">Report Issue</span>
            </div>
          </Button>
          
          <Button 
            className="h-auto py-3 bg-chart-5 hover:bg-chart-5/90 text-white"
            onClick={() => onActionClick('team_chat')}
            data-testid="button-team-chat"
          >
            <div className="flex flex-col items-center gap-1">
              <Users className="w-5 h-5" />
              <span className="text-sm">Team Chat</span>
            </div>
          </Button>
        </div>
      </div>
    </div>
  );
}
import { useState } from "react";
import { X, Camera, Flashlight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface QRScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (data: string) => void;
  userRole: 'citizen' | 'field_staff';
}

export default function QRScannerModal({ isOpen, onClose, onScanSuccess, userRole }: QRScannerModalProps) {
  const [isFlashOn, setIsFlashOn] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  if (!isOpen) return null;

  const handleScanSuccess = () => {
    setIsScanning(true);
    // Simulate scanning delay
    setTimeout(() => {
      setIsScanning(false);
      const mockData = userRole === 'citizen' ? 'WASTE_KIOSK_001' : 'BIN_ROUTE_045';
      onScanSuccess(mockData);
    }, 2000);
  };

  const getScanText = () => {
    if (userRole === 'citizen') {
      return {
        title: 'Scan Waste Kiosk',
        subtitle: 'Point your camera at the QR code on the waste kiosk to earn points'
      };
    } else {
      return {
        title: 'Scan Collection Bin',
        subtitle: 'Scan the bin QR code to log collection completion'
      };
    }
  };

  const { title, subtitle } = getScanText();

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex flex-col">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-4 flex items-center justify-between">
        <div>
          <h2 className="font-semibold">{title}</h2>
          <p className="text-sm text-primary-foreground/80">{subtitle}</p>
        </div>
        <Button 
          size="icon" 
          variant="ghost" 
          className="text-primary-foreground hover:bg-primary-foreground/20"
          onClick={onClose}
          data-testid="button-close-scanner"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>

      {/* Scanner Area */}
      <div className="flex-1 relative bg-black flex items-center justify-center">
        {/* Mock Camera View */}
        <div className="relative w-80 h-80 bg-gray-900 rounded-lg flex items-center justify-center">
          {/* Scanning Frame */}
          <div className="relative w-64 h-64 border-2 border-white rounded-lg">
            <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-primary rounded-tl-lg"></div>
            <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-primary rounded-tr-lg"></div>
            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-primary rounded-bl-lg"></div>
            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-primary rounded-br-lg"></div>
            
            {/* Scanning Line Animation */}
            {isScanning && (
              <div className="absolute top-0 left-0 right-0 h-1 bg-primary animate-pulse"></div>
            )}
            
            {/* Camera Icon */}
            {!isScanning && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Camera className="w-12 h-12 text-white/50" />
              </div>
            )}
          </div>
        </div>

        {/* Flash Toggle */}
        <Button
          size="icon"
          variant="ghost"
          className={`absolute top-4 right-4 ${isFlashOn ? 'bg-white/20' : ''}`}
          onClick={() => setIsFlashOn(!isFlashOn)}
          data-testid="button-toggle-flash"
        >
          <Flashlight className={`w-6 h-6 ${isFlashOn ? 'text-yellow-400' : 'text-white'}`} />
        </Button>
      </div>

      {/* Bottom Actions */}
      <div className="bg-card p-4 space-y-3">
        <Card className="bg-muted/50">
          <CardContent className="p-3 text-center">
            <p className="text-sm text-muted-foreground">
              {isScanning ? 'Scanning QR code...' : 'Position the QR code within the frame above'}
            </p>
          </CardContent>
        </Card>
        
        {/* Mock Scan Button for Demo */}
        <Button 
          className="w-full" 
          onClick={handleScanSuccess}
          disabled={isScanning}
          data-testid="button-mock-scan"
        >
          {isScanning ? 'Scanning...' : 'Simulate Scan (Demo)'}
        </Button>
      </div>
    </div>
  );
}
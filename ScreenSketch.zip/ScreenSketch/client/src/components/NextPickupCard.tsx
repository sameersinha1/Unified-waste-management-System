import { Calendar, MapPin, Trash2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface NextPickupCardProps {
  date: string;
  time: string;
  wasteType: string;
  status: 'scheduled' | 'in_progress' | 'completed';
}

export default function NextPickupCard({ date, time, wasteType, status }: NextPickupCardProps) {
  const getStatusColor = () => {
    switch (status) {
      case 'scheduled': return 'bg-secondary text-secondary-foreground';
      case 'in_progress': return 'bg-chart-3 text-white';
      case 'completed': return 'bg-chart-4 text-white';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'scheduled': return 'Scheduled';
      case 'in_progress': return 'In Progress';
      case 'completed': return 'Completed';
    }
  };

  return (
    <Card className="border-card-border">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" />
            <span className="font-medium text-sm">Next Pickup</span>
          </div>
          <Badge className={getStatusColor()}>
            {getStatusText()}
          </Badge>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm">
            <span className="font-medium">{date}, {time}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Trash2 className="w-4 h-4" />
            <span>{wasteType}</span>
          </div>
        </div>
        
        <div className="mt-3 pt-3 border-t border-card-border">
          <button 
            className="text-xs text-primary hover:underline flex items-center gap-1"
            onClick={() => console.log('View details triggered')}
            data-testid="link-pickup-details"
          >
            <MapPin className="w-3 h-3" />
            View pickup details
          </button>
        </div>
      </CardContent>
    </Card>
  );
}
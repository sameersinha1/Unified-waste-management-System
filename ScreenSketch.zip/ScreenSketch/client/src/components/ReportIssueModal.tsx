import { useState } from "react";
import { X, Camera, MapPin, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ReportIssueModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (issue: { type: string; description: string; location: string; photo?: File }) => void;
}

export default function ReportIssueModal({ isOpen, onClose, onSubmit }: ReportIssueModalProps) {
  const [issueType, setIssueType] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [hasPhoto, setHasPhoto] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = () => {
    console.log('Issue report submitted');
    onSubmit({
      type: issueType,
      description,
      location,
    });
    
    // Reset form
    setIssueType("");
    setDescription("");
    setLocation("");
    setHasPhoto(false);
  };

  const handleTakePhoto = () => {
    console.log('Take photo triggered');
    setHasPhoto(true);
  };

  const handleUseCurrentLocation = () => {
    console.log('Use current location triggered');
    setLocation("Current Location (GPS)");
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <Card className="w-full max-h-[90vh] overflow-y-auto rounded-t-lg rounded-b-none border-b-0">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-chart-5" />
              <CardTitle>Report an Issue</CardTitle>
            </div>
            <Button 
              size="icon" 
              variant="ghost"
              onClick={onClose}
              data-testid="button-close-report"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="issue-type">Issue Type</Label>
            <Select value={issueType} onValueChange={setIssueType}>
              <SelectTrigger data-testid="select-issue-type">
                <SelectValue placeholder="Select issue type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="overflowing_bin">Overflowing Bin</SelectItem>
                <SelectItem value="damaged_bin">Damaged Bin</SelectItem>
                <SelectItem value="missed_collection">Missed Collection</SelectItem>
                <SelectItem value="illegal_dumping">Illegal Dumping</SelectItem>
                <SelectItem value="broken_kiosk">Broken Kiosk</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Please describe the issue in detail..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="min-h-[100px]"
              data-testid="textarea-description"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <div className="flex gap-2">
              <Input
                id="location"
                placeholder="Enter location or address"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="flex-1"
                data-testid="input-location"
              />
              <Button 
                size="icon" 
                variant="outline"
                onClick={handleUseCurrentLocation}
                data-testid="button-current-location"
              >
                <MapPin className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Photo Evidence (Optional)</Label>
            <div className="flex items-center gap-2">
              {hasPhoto ? (
                <div className="flex-1 p-3 border border-card-border rounded-md bg-muted/50 flex items-center gap-2">
                  <Camera className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Photo captured</span>
                </div>
              ) : (
                <Button 
                  variant="outline" 
                  className="flex-1 gap-2"
                  onClick={handleTakePhoto}
                  data-testid="button-take-photo"
                >
                  <Camera className="w-4 h-4" />
                  Take Photo
                </Button>
              )}
            </div>
          </div>

          <div className="flex gap-2 pt-4">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={onClose}
              data-testid="button-cancel-report"
            >
              Cancel
            </Button>
            <Button 
              className="flex-1" 
              onClick={handleSubmit}
              disabled={!issueType || !description || !location}
              data-testid="button-submit-report"
            >
              Submit Report
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
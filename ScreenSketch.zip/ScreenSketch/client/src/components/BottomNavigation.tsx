import { Home, Calendar, QrCode, AlertTriangle, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  userRole: 'citizen' | 'field_staff' | 'admin';
}

export default function BottomNavigation({ activeTab, onTabChange, userRole }: BottomNavigationProps) {
  const citizenTabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'schedule', icon: Calendar, label: 'Schedule' },
    { id: 'scan', icon: QrCode, label: 'Scan' },
    { id: 'report', icon: AlertTriangle, label: 'Report' },
    { id: 'profile', icon: Settings, label: 'Profile' },
  ];

  const fieldStaffTabs = [
    { id: 'routes', icon: Home, label: 'Routes' },
    { id: 'scan', icon: QrCode, label: 'Scan' },
    { id: 'report', icon: AlertTriangle, label: 'Report' },
    { id: 'profile', icon: Settings, label: 'Profile' },
  ];

  const adminTabs = [
    { id: 'dashboard', icon: Home, label: 'Dashboard' },
    { id: 'analytics', icon: Calendar, label: 'Analytics' },
    { id: 'manage', icon: Settings, label: 'Manage' },
  ];

  const getTabs = () => {
    switch (userRole) {
      case 'citizen': return citizenTabs;
      case 'field_staff': return fieldStaffTabs;
      case 'admin': return adminTabs;
    }
  };

  const tabs = getTabs();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-card-border">
      <div className="flex items-center justify-around px-2 py-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <Button
              key={tab.id}
              variant="ghost"
              size="sm"
              className={`flex flex-col items-center gap-1 h-auto py-2 px-3 ${
                isActive 
                  ? 'text-primary bg-primary/10' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
              onClick={() => onTabChange(tab.id)}
              data-testid={`nav-${tab.id}`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs">{tab.label}</span>
            </Button>
          );
        })}
      </div>
    </nav>
  );
}
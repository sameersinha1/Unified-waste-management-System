import { Bell, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface MobileHeaderProps {
  userName: string;
  points: number;
  userRole: 'citizen' | 'field_staff' | 'admin';
}

export default function MobileHeader({ userName, points, userRole }: MobileHeaderProps) {
  const getRoleDisplay = () => {
    switch (userRole) {
      case 'citizen': return 'Citizen';
      case 'field_staff': return 'Field Staff';
      case 'admin': return 'Admin';
    }
  };

  return (
    <header className="bg-primary text-primary-foreground px-4 py-6 pb-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center">
            <User className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-semibold">Hello, {userName}!</h1>
            <p className="text-sm text-primary-foreground/80">Welcome back to your dashboard</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            size="icon" 
            variant="ghost" 
            className="text-primary-foreground hover:bg-primary-foreground/20"
            data-testid="button-notifications"
          >
            <Bell className="w-5 h-5" />
          </Button>
          <Badge variant="secondary" className="text-xs">
            {getRoleDisplay()}
          </Badge>
        </div>
      </div>
      
      {userRole === 'citizen' && (
        <div className="bg-primary-foreground/10 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-primary-foreground/80">Your Reward Points</p>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold">⭐ {points}</span>
                <Badge variant="outline" className="text-xs bg-accent text-accent-foreground border-accent">
                  Active
                </Badge>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
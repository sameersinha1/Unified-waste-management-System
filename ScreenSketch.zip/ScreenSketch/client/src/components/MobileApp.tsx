import { useState } from "react";
import MobileHeader from "./MobileHeader";
import BottomNavigation from "./BottomNavigation";
import NextPickupCard from "./NextPickupCard";
import QuickActionsGrid from "./QuickActionsGrid";
import TipsUpdatesSection from "./TipsUpdatesSection";
import EmployeeHomeScreen from "./EmployeeHomeScreen";
import QRScannerModal from "./QRScannerModal";
import ReportIssueModal from "./ReportIssueModal";
import LoginScreen from "./LoginScreen";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { api } from "@/lib/api";

interface User {
  id: string;
  name: string;
  role: 'citizen' | 'field_staff' | 'admin';
  points: number;
  employeeId?: string;
}

export default function MobileApp() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('home');
  const [showScanner, setShowScanner] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const { toast } = useToast();

  // Mock data - todo: remove mock functionality
  const mockTipsUpdates = [
    {
      id: '1',
      type: 'tip' as const,
      title: 'Recycling Tip',
      description: 'Clean plastic containers before disposal to improve recycling efficiency and earn bonus points!',
      isNew: false
    },
    {
      id: '2',
      type: 'update' as const,
      title: 'System Update',
      description: 'New QR code kiosks installed at Central Park and City Mall. Start earning points today!',
      isNew: true
    },
    {
      id: '3',
      type: 'reward' as const,
      title: 'Reward Alert',
      description: 'You\'re only 250 points away from a free movie ticket! Keep scanning to reach your goal.',
      isNew: false
    }
  ];

  const handleLogin = async (credentials: { identifier: string; password: string; role: string }) => {
    console.log('Login attempt:', credentials);
    
    const response = await api.login(credentials.identifier, credentials.password);
    
    if (response.error) {
      toast({
        title: "Login Failed",
        description: response.error,
        variant: "destructive",
      });
      return;
    }

    if (response.data?.user) {
      const userData = response.data.user;
      setUser({
        id: userData.id,
        name: userData.name,
        role: userData.role,
        points: userData.points || 0,
        employeeId: userData.employeeId
      });
      
      toast({
        title: "Welcome back!",
        description: `Successfully logged in as ${userData.role === 'field_staff' ? 'Employee' : userData.role === 'admin' ? 'Administrator' : 'Citizen'}`,
      });
    }
  };

  const handleActionClick = (action: string) => {
    console.log('Action clicked:', action);
    
    switch (action) {
      case 'scan_waste':
      case 'scan_bin':
      case 'scan_collection':
        setShowScanner(true);
        break;
      case 'report_issue':
      case 'report_maintenance':
        setShowReportModal(true);
        break;
      case 'find_kiosks':
        toast({
          title: "Map Feature",
          description: "Opening map to show nearby waste kiosks...",
        });
        break;
      case 'rewards':
        toast({
          title: "Rewards Store",
          description: "Opening rewards catalog...",
        });
        break;
      case 'view_route':
        toast({
          title: "Route Map",
          description: "Opening today's collection route...",
        });
        break;
      case 'team_chat':
        toast({
          title: "Team Communication",
          description: "Opening team chat channel...",
        });
        break;
      default:
        if (action.startsWith('task_')) {
          toast({
            title: "Task Details",
            description: "Opening task details and instructions...",
          });
        } else {
          toast({
            title: action.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()),
            description: "Feature coming soon!",
          });
        }
    }
  };

  const handleScanSuccess = async (data: string) => {
    console.log('Scan successful:', data);
    setShowScanner(false);
    
    if (!user) return;
    
    if (user.role === 'citizen') {
      const response = await api.scanForPoints(data);
      
      if (response.error) {
        toast({
          title: "Scan Failed",
          description: response.error,
          variant: "destructive",
        });
        return;
      }

      if (response.data) {
        setUser(prev => prev ? {...prev, points: response.data!.totalPoints} : null);
        
        toast({
          title: "Scan Successful! ⭐",
          description: `You earned ${response.data.pointsEarned} points! Total: ${response.data.totalPoints}`,
        });
      }
    } else if (user.role === 'field_staff') {
      const response = await api.logCollection(data);
      
      if (response.error) {
        toast({
          title: "Logging Failed",
          description: response.error,
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Collection Logged ✓",
        description: `${data} successfully logged. Route progress updated.`,
      });
    }
  };

  const handleReportSubmit = async (issue: any) => {
    console.log('Issue reported:', issue);
    
    if (!user) return;
    
    const response = await api.reportIssue({
      type: issue.type,
      description: issue.description,
      location: issue.location,
      photoUrl: issue.photo ? 'photo-placeholder' : undefined
    });
    
    setShowReportModal(false);
    
    if (response.error) {
      toast({
        title: "Report Failed",
        description: response.error,
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Report Submitted",
      description: "Thank you for reporting this issue. We'll investigate promptly.",
    });
  };

  const handleLogout = async () => {
    await api.logout(); // Clear server session
    setUser(null);
    setActiveTab('home');
    
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
  };

  if (!user) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Layout */}
      <div className="max-w-sm mx-auto bg-background min-h-screen relative">
        {/* Header */}
        <MobileHeader 
          userName={user.name}
          points={user.points}
          userRole={user.role}
        />

        {/* Main Content */}
        <main className="pb-20 px-0"> {/* Bottom padding for fixed nav */}
          {activeTab === 'home' && user.role === 'field_staff' && (
            <div className="py-4">
              <EmployeeHomeScreen 
                employeeName={user.name}
                employeeId={user.employeeId || 'EMP001'}
                onActionClick={handleActionClick}
              />
            </div>
          )}
          
          {activeTab === 'home' && user.role !== 'field_staff' && (
            <div className="space-y-6 py-4">
              {/* Next Pickup (Citizens only) */}
              {user.role === 'citizen' && (
                <div className="px-4">
                  <NextPickupCard 
                    date="Tomorrow" 
                    time="8:00 AM" 
                    wasteType="Mixed Waste Collection" 
                    status="scheduled" 
                  />
                </div>
              )}

              {/* Quick Actions */}
              <QuickActionsGrid 
                userRole={user.role} 
                onActionClick={handleActionClick}
              />

              {/* Tips & Updates */}
              <TipsUpdatesSection items={mockTipsUpdates} />
            </div>
          )}

          {/* Other tab content would go here */}
          {activeTab !== 'home' && (
            <div className="p-4 text-center space-y-4">
              <h2 className="text-xl font-semibold capitalize">{activeTab}</h2>
              <p className="text-muted-foreground">
                {activeTab} content would be implemented here.
              </p>
              
              {/* Demo logout button */}
              <Button 
                variant="outline" 
                onClick={handleLogout}
                data-testid="button-logout"
              >
                Logout (Demo)
              </Button>
            </div>
          )}
        </main>

        {/* Bottom Navigation */}
        <BottomNavigation 
          activeTab={activeTab}
          onTabChange={setActiveTab}
          userRole={user.role}
        />

        {/* Modals */}
        <QRScannerModal 
          isOpen={showScanner}
          onClose={() => setShowScanner(false)}
          onScanSuccess={handleScanSuccess}
          userRole={user.role === 'admin' ? 'citizen' : user.role}
        />

        <ReportIssueModal 
          isOpen={showReportModal}
          onClose={() => setShowReportModal(false)}
          onSubmit={handleReportSubmit}
        />
      </div>
    </div>
  );
}
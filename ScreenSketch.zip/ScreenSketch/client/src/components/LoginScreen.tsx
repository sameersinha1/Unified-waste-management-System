import { useState } from "react";
import { Recycle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

interface LoginScreenProps {
  onLogin: (credentials: { identifier: string; password: string; role: string }) => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    console.log('Login triggered');
    onLogin({ identifier, password, role: 'citizen' });
  };

  const handleSendOTP = () => {
    console.log('Send OTP triggered');
  };

  const handleRegister = () => {
    console.log('Register triggered');
  };

  const handleForgotPassword = () => {
    console.log('Forgot password triggered');
  };

  return (
    <div className="min-h-screen bg-muted flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-sm space-y-6">
        {/* Logo and Branding */}
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto">
            <Recycle className="w-8 h-8 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Cyber City</h1>
            <p className="text-muted-foreground">Waste Management System</p>
          </div>
        </div>

        {/* Login Form */}
        <Card>
          <CardHeader className="text-center pb-4">
            <h2 className="text-xl font-semibold">Sign In</h2>
            <p className="text-sm text-muted-foreground">
              Enter your credentials to access the system
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="identifier">Mobile Number / Employee ID</Label>
              <Input
                id="identifier"
                type="text"
                placeholder="Enter your mobile number or employee ID"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                data-testid="input-identifier"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                data-testid="input-password"
              />
            </div>

            <Button 
              className="w-full" 
              onClick={handleLogin}
              data-testid="button-login"
            >
              Login
            </Button>

            <div className="text-center">
              <span className="text-sm text-muted-foreground">OR</span>
            </div>

            <Button 
              variant="outline" 
              className="w-full gap-2"
              onClick={handleSendOTP}
              data-testid="button-send-otp"
            >
              <Phone className="w-4 h-4" />
              Send OTP
            </Button>
          </CardContent>
        </Card>

        {/* Additional Actions */}
        <div className="text-center space-y-3">
          <button 
            className="text-primary font-medium underline"
            onClick={handleRegister}
            data-testid="link-register"
          >
            New Citizen? Register Here
          </button>
          
          <button 
            className="block text-sm text-muted-foreground underline mx-auto"
            onClick={handleForgotPassword}
            data-testid="link-forgot-password"
          >
            Forgot Password?
          </button>
        </div>

        {/* Demo Instructions */}
        <div className="bg-card p-4 rounded-lg border border-card-border">
          <h3 className="font-medium text-sm mb-2">Demo Instructions:</h3>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>• Phone number (9xxxxxxxxx) for Citizen access</li>
            <li>• EMP001 for Field Staff access</li>
            <li>• Any password works for demo</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
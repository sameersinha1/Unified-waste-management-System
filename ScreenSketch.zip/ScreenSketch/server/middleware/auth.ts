import { Request, Response, NextFunction } from "express";
import { storage } from "../storage";
import { User } from "@shared/schema";

// Extend Express types to include session and user
declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}

declare module 'express-session' {
  interface SessionData {
    userId?: string;
  }
}

export interface AuthenticatedRequest extends Request {
  user: User;
}

// Middleware to check if user is authenticated
export async function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  const userId = req.session.userId;
  
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  try {
    const user = await storage.getUser(userId);
    if (!user) {
      req.session.destroy(() => {});
      res.status(401).json({ error: "Invalid session" });
      return;
    }

    req.user = user;
    next();
  } catch (error) {
    console.error("Auth middleware error:", error);
    res.status(500).json({ error: "Authentication error" });
  }
}

// Middleware to check if user has required role
export function requireRole(...allowedRoles: string[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const user = req.user;
    
    if (!user) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }

    if (!allowedRoles.includes(user.role)) {
      res.status(403).json({ error: "Insufficient permissions" });
      return;
    }

    next();
  };
}

// CSRF protection middleware - validate Origin header for state-changing requests
export function csrfProtection(req: Request, res: Response, next: NextFunction): void {
  // Skip CSRF check for GET requests and auth endpoints
  if (req.method === 'GET' || req.path.startsWith('/api/auth/')) {
    next();
    return;
  }

  const origin = req.get('Origin') || req.get('Referer');
  const host = req.get('Host');
  
  if (!origin) {
    res.status(403).json({ error: "Missing origin header" });
    return;
  }

  try {
    const originUrl = new URL(origin);
    const expectedHost = host?.split(':')[0]; // Remove port for comparison
    
    if (originUrl.hostname !== expectedHost && originUrl.hostname !== 'localhost') {
      res.status(403).json({ error: "Invalid origin" });
      return;
    }
  } catch (error) {
    res.status(403).json({ error: "Invalid origin format" });
    return;
  }

  next();
}

// Middleware to check if user is a citizen
export const requireCitizen = [requireAuth, requireRole('citizen')];

// Middleware to check if user is field staff
export const requireFieldStaff = [requireAuth, requireRole('field_staff')];

// Middleware to check if user is admin
export const requireAdmin = [requireAuth, requireRole('admin')];

// Middleware to check if user is staff or admin
export const requireStaff = [requireAuth, requireRole('field_staff', 'admin')];
import { storage } from "./storage";
import bcrypt from "bcryptjs";

export async function seedDatabase() {
  try {
    console.log("🌱 Seeding database...");

    // Create demo users - check if they exist first
    const demoPassword = await bcrypt.hash("demo123", 10);

    // Create citizen user if not exists
    let citizen = await storage.getUserByIdentifier("9876543210");
    if (!citizen) {
      citizen = await storage.createUser({
        identifier: "9876543210",
        password: demoPassword,
        name: "Demo Citizen",
        role: "citizen",
        employeeId: null
      });
    }

    // Create field staff user if not exists
    let fieldStaff = await storage.getUserByIdentifier("EMP001");
    if (!fieldStaff) {
      fieldStaff = await storage.createUser({
        identifier: "EMP001",
        password: demoPassword,
        name: "John Smith",
        role: "field_staff",
        employeeId: "EMP001"
      });
    }

    // Create admin user if not exists
    let admin = await storage.getUserByIdentifier("admin");
    if (!admin) {
      admin = await storage.createUser({
        identifier: "admin",
        password: demoPassword,
        name: "System Admin",
        role: "admin",
        employeeId: null
      });
    }

    console.log("👤 Created demo users:");
    console.log("  - Citizen: 9876543210 / demo123");
    console.log("  - Employee: EMP001 / demo123");
    console.log("  - Admin: admin / demo123");

    // Create waste bins with QR codes - check if they exist first
    const wasteBins = [
      { qrCode: "BIN_CP_001", location: "Central Park - North Gate", type: "mixed" },
      { qrCode: "BIN_CP_002", location: "Central Park - South Gate", type: "recyclable" },
      { qrCode: "BIN_CM_001", location: "City Mall - Main Entrance", type: "mixed" },
      { qrCode: "BIN_CM_002", location: "City Mall - Food Court", type: "organic" },
      { qrCode: "BIN_RS_001", location: "Residential Street A", type: "mixed" },
      { qrCode: "BIN_RS_002", location: "Residential Street B", type: "recyclable" },
    ];

    for (const bin of wasteBins) {
      const existing = await storage.getWasteBin(bin.qrCode);
      if (!existing) {
        await storage.db.insert(storage.schema.wasteBins).values(bin);
      }
    }

    // Create kiosk QR codes for citizen scanning
    const kiosks = [
      { qrCode: "WASTE_KIOSK_001", location: "Central Park Kiosk", type: "kiosk" },
      { qrCode: "WASTE_KIOSK_002", location: "City Mall Kiosk", type: "kiosk" },
      { qrCode: "WASTE_KIOSK_003", location: "Community Center Kiosk", type: "kiosk" },
    ];

    for (const kiosk of kiosks) {
      const existing = await storage.getWasteBin(kiosk.qrCode);
      if (!existing) {
        await storage.db.insert(storage.schema.wasteBins).values(kiosk);
      }
    }

    console.log("🗑️  Created waste bins and kiosks");

    // Create a route for the field staff
    const today = new Date();
    await storage.db.insert(storage.schema.routes).values({
      name: "Downtown Collection Route",
      assignedTo: fieldStaff.id,
      date: today,
      totalBins: 12,
      completedBins: 8,
      status: "in_progress"
    });

    console.log("🚛 Created demo route for field staff");

    // Give citizen some initial points
    await storage.updateUserPoints(citizen.id, 850);

    console.log("⭐ Gave citizen initial points");
    console.log("✅ Database seeded successfully!");

  } catch (error) {
    console.error("❌ Error seeding database:", error);
  }
}
import type { Express } from "express";
import { createServer, type Server } from "http";
import bcrypt from "bcryptjs";
import rateLimit from "express-rate-limit";
import { storage } from "./storage";
import { seedDatabase } from "./seed";
import { insertUserSchema } from "@shared/schema";
import { requireAuth, requireRole, requireCitizen, requireFieldStaff, requireStaff, csrfProtection } from "./middleware/auth";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Apply CSRF protection to all routes except GET and auth
  app.use(csrfProtection);
  
  // Rate limiting
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // 5 attempts per window
    message: { error: "Too many login attempts, please try again later" },
    standardHeaders: true,
    legacyHeaders: false,
  });

  const scanLimiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 10, // 10 scans per minute
    message: { error: "Too many scan attempts, please slow down" },
  });

  // Seed database on startup (dev only) - temporarily disabled to avoid duplicates
  /*
  if (process.env.NODE_ENV === 'development') {
    try {
      await seedDatabase();
    } catch (error) {
      console.log("Database already seeded or error occurred:", error instanceof Error ? error.message : String(error));
    }
  }
  */
  
  // Authentication routes
  app.post("/api/auth/login", authLimiter, async (req, res) => {
    try {
      const { identifier, password } = req.body;
      
      if (!identifier || !password) {
        return res.status(400).json({ error: "Identifier and password are required" });
      }

      const user = await storage.getUserByIdentifier(identifier);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Regenerate session to prevent session fixation
      req.session.regenerate((err) => {
        if (err) {
          console.error("Session regeneration error:", err);
          return res.status(500).json({ error: "Login failed" });
        }

        // Set session
        req.session.userId = user.id;

        // Save session
        req.session.save((err) => {
          if (err) {
            console.error("Session save error:", err);
            return res.status(500).json({ error: "Login failed" });
          }

          // Don't send password back
          const { password: _, ...userWithoutPassword } = user;
          res.json({ user: userWithoutPassword, message: "Login successful" });
        });
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/auth/register", authLimiter, async (req, res) => {
    try {
      // Only allow citizen registration, force role to citizen
      const userData = insertUserSchema.parse({
        ...req.body,
        role: 'citizen', // Force citizen role for security
        employeeId: null, // Citizens don't have employee IDs
      });
      
      // Check if user already exists
      const existingUser = await storage.getUserByIdentifier(userData.identifier);
      if (existingUser) {
        return res.status(409).json({ error: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const newUser = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Regenerate session for auto-login to prevent session fixation
      req.session.regenerate((err) => {
        if (err) {
          console.error("Session regeneration error:", err);
          return res.status(500).json({ error: "Registration failed" });
        }

        // Set session for auto-login
        req.session.userId = newUser.id;

        // Save session
        req.session.save((err) => {
          if (err) {
            console.error("Session save error:", err);
            return res.status(500).json({ error: "Registration failed" });
          }

          // Don't send password back
          const { password: _, ...userWithoutPassword } = newUser;
          res.status(201).json({ user: userWithoutPassword, message: "User created successfully" });
        });
      });
    } catch (error) {
      console.error("Registration error:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ error: "Invalid input data", details: error.errors });
      }
      
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Citizen scanning for points
  app.post("/api/scan", scanLimiter, ...requireCitizen, async (req, res) => {
    try {
      const { qrCode } = req.body;
      const user = req.user!; // Guaranteed by requireCitizen middleware
      
      if (!qrCode) {
        return res.status(400).json({ error: "QR code is required" });
      }

      // Verify QR code exists in database and is a kiosk
      const bin = await storage.getWasteBin(qrCode);
      if (!bin) {
        return res.status(400).json({ error: "Invalid QR code" });
      }

      if (bin.type !== 'kiosk') {
        return res.status(400).json({ error: "QR code is not a valid kiosk" });
      }

      // Calculate points (5-25 randomly)
      const pointsEarned = Math.floor(Math.random() * 21) + 5;
      
      // Log the scan
      await storage.logScan({ userId: user.id, qrCode, pointsEarned });
      
      // Update user points
      const updatedUser = await storage.updateUserPoints(user.id, pointsEarned);
      
      res.json({ 
        pointsEarned, 
        totalPoints: updatedUser?.points || 0,
        message: "Scan successful! Points earned." 
      });
    } catch (error) {
      console.error("Scan error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Employee collection logging
  app.post("/api/collect", ...requireFieldStaff, async (req, res) => {
    try {
      const { qrCode, wasteAmount, notes } = req.body;
      const employee = req.user!; // Guaranteed by requireFieldStaff middleware
      
      if (!qrCode) {
        return res.status(400).json({ error: "QR code is required" });
      }

      // Get waste bin by QR code
      const bin = await storage.getWasteBin(qrCode);
      if (!bin) {
        return res.status(404).json({ error: "Waste bin not found" });
      }

      if (bin.type === 'kiosk') {
        return res.status(400).json({ error: "Cannot collect from kiosks" });
      }

      // Log the collection
      const collectionLog = await storage.logCollection({
        binId: bin.id,
        employeeId: employee.id,
        wasteAmount,
        notes
      });

      res.json({ 
        collectionLog,
        message: "Collection logged successfully" 
      });
    } catch (error) {
      console.error("Collection error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Issue reporting
  app.post("/api/issues", requireAuth, async (req, res) => {
    try {
      const { type, description, location, photoUrl } = req.body;
      const reporter = req.user!; // Guaranteed by requireAuth middleware
      
      if (!type || !description || !location) {
        return res.status(400).json({ error: "Type, description, and location are required" });
      }

      const issueReport = await storage.createIssueReport({
        reporterId: reporter.id,
        type,
        description,
        location,
        photoUrl
      });

      res.status(201).json({ 
        issueReport,
        message: "Issue reported successfully" 
      });
    } catch (error) {
      console.error("Issue reporting error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get user profile/stats (own profile only, or admin can see others)
  app.get("/api/users/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const currentUser = req.user!;
      
      // Users can only access their own profile, unless they're admin
      if (currentUser.id !== id && currentUser.role !== 'admin') {
        return res.status(403).json({ error: "Can only access your own profile" });
      }

      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Don't send password
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get employee's today collections (for dashboard stats)
  app.get("/api/employees/:id/collections", ...requireStaff, async (req, res) => {
    try {
      const { id } = req.params;
      const currentUser = req.user!;
      
      // Field staff can only see their own collections, admins can see all
      if (currentUser.role === 'field_staff' && currentUser.id !== id) {
        return res.status(403).json({ error: "Can only access your own collections" });
      }
      
      const today = new Date();
      const collections = await storage.getCollectionsByEmployee(id, today);
      res.json({ collections, count: collections.length });
    } catch (error) {
      console.error("Get collections error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get all issues (for admin/staff)
  app.get("/api/issues", ...requireStaff, async (req, res) => {
    try {
      const issues = await storage.getIssueReports();
      res.json({ issues });
    } catch (error) {
      console.error("Get issues error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Logout route - properly implemented
  app.post("/api/auth/logout", (req, res) => {
    if (!req.session.userId) {
      return res.status(400).json({ error: "Not logged in" });
    }

    req.session.destroy((err) => {
      if (err) {
        console.error("Session destroy error:", err);
        return res.status(500).json({ error: "Could not log out" });
      }
      
      // Clear the session cookie
      res.clearCookie('connect.sid');
      res.json({ message: "Logged out successfully" });
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}

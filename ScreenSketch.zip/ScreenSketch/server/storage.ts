import { eq, desc } from "drizzle-orm";
import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import { 
  users, 
  wasteBins, 
  collectionLogs, 
  scanLogs, 
  issueReports, 
  routes,
  type User, 
  type InsertUser,
  type WasteBin,
  type CollectionLog,
  type ScanLog,
  type IssueReport,
  type Route
} from "@shared/schema";

const sql = neon(process.env.DATABASE_URL!);
const db = drizzle(sql);

// Export db and schema for seeding
export { db, users, wasteBins, collectionLogs, scanLogs, issueReports, routes };

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByIdentifier(identifier: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: string, pointsToAdd: number): Promise<User | undefined>;

  // Waste bin operations
  getWasteBin(qrCode: string): Promise<WasteBin | undefined>;
  getAllWasteBins(): Promise<WasteBin[]>;
  
  // Collection operations
  logCollection(log: { binId: string; employeeId: string; wasteAmount?: number; notes?: string }): Promise<CollectionLog>;
  getCollectionsByEmployee(employeeId: string, date?: Date): Promise<CollectionLog[]>;
  
  // Scan operations (for citizen points)
  logScan(scan: { userId: string; qrCode: string; pointsEarned: number }): Promise<ScanLog>;
  getUserScans(userId: string): Promise<ScanLog[]>;
  
  // Issue reporting
  createIssueReport(report: { reporterId: string; type: string; description: string; location: string; photoUrl?: string }): Promise<IssueReport>;
  getIssueReports(): Promise<IssueReport[]>;
  updateIssueStatus(reportId: string, status: string, assignedTo?: string): Promise<IssueReport | undefined>;
  
  // Route management
  getEmployeeRoute(employeeId: string, date?: Date): Promise<Route | undefined>;
  updateRouteProgress(routeId: string, completedBins: number): Promise<Route | undefined>;
}

export class DatabaseStorage implements IStorage {
  // Expose db and schema for seeding
  public db = db;
  public schema = { users, wasteBins, collectionLogs, scanLogs, issueReports, routes };

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByIdentifier(identifier: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.identifier, identifier)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUserPoints(userId: string, pointsToAdd: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const result = await db.update(users)
      .set({ points: (user.points || 0) + pointsToAdd })
      .where(eq(users.id, userId))
      .returning();
    return result[0];
  }

  // Waste bin operations
  async getWasteBin(qrCode: string): Promise<WasteBin | undefined> {
    const result = await db.select().from(wasteBins).where(eq(wasteBins.qrCode, qrCode)).limit(1);
    return result[0];
  }

  async getAllWasteBins(): Promise<WasteBin[]> {
    return await db.select().from(wasteBins);
  }

  // Collection operations
  async logCollection(log: { binId: string; employeeId: string; wasteAmount?: number; notes?: string }): Promise<CollectionLog> {
    const result = await db.insert(collectionLogs).values(log).returning();
    return result[0];
  }

  async getCollectionsByEmployee(employeeId: string, date?: Date): Promise<CollectionLog[]> {
    let query = db.select().from(collectionLogs).where(eq(collectionLogs.employeeId, employeeId));
    
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
    }
    
    return await query.orderBy(desc(collectionLogs.collectedAt));
  }

  // Scan operations
  async logScan(scan: { userId: string; qrCode: string; pointsEarned: number }): Promise<ScanLog> {
    const result = await db.insert(scanLogs).values(scan).returning();
    return result[0];
  }

  async getUserScans(userId: string): Promise<ScanLog[]> {
    return await db.select().from(scanLogs)
      .where(eq(scanLogs.userId, userId))
      .orderBy(desc(scanLogs.scannedAt));
  }

  // Issue reporting
  async createIssueReport(report: { reporterId: string; type: string; description: string; location: string; photoUrl?: string }): Promise<IssueReport> {
    const result = await db.insert(issueReports).values(report).returning();
    return result[0];
  }

  async getIssueReports(): Promise<IssueReport[]> {
    return await db.select().from(issueReports).orderBy(desc(issueReports.createdAt));
  }

  async updateIssueStatus(reportId: string, status: string, assignedTo?: string): Promise<IssueReport | undefined> {
    const updateData: any = { status };
    if (assignedTo) updateData.assignedTo = assignedTo;
    if (status === 'resolved') updateData.resolvedAt = new Date();
    
    const result = await db.update(issueReports)
      .set(updateData)
      .where(eq(issueReports.id, reportId))
      .returning();
    return result[0];
  }

  // Route management
  async getEmployeeRoute(employeeId: string, date?: Date): Promise<Route | undefined> {
    let query = db.select().from(routes).where(eq(routes.assignedTo, employeeId));
    
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
    }
    
    const result = await query.limit(1);
    return result[0];
  }

  async updateRouteProgress(routeId: string, completedBins: number): Promise<Route | undefined> {
    const result = await db.update(routes)
      .set({ 
        completedBins,
        status: 'in_progress'
      })
      .where(eq(routes.id, routeId))
      .returning();
    return result[0];
  }
}

export const storage = new DatabaseStorage();

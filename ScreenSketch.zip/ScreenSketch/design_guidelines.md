# Cyber City Waste Management System - Mobile Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern mobile-first applications like Uber, Spotify, and banking apps that prioritize utility, gamification, and role-based interfaces. The design emphasizes accessibility for field conditions and intuitive navigation across three distinct user roles.

## Core Design Elements

### Color Palette
- **Primary Green**: 174 88% 26% (Brand identity, CTAs, active states)
- **Secondary Blue**: 217 91% 60% (Navigation, info states)
- **Accent Orange**: 38 95% 50% (Rewards, achievements, notifications)
- **Warning Red**: 0 84% 60% (Alerts, errors)
- **Success Green**: 142 71% 45% (Confirmations, completed tasks)
- **Neutral Gray**: 220 14% 46% (Text, borders, inactive states)
- **Dark backgrounds**: 220 26% 14% for dark mode compatibility

### Typography
- **Primary Font**: Inter (Google Fonts)
- **Heading Sizes**: text-2xl (32px), text-xl (24px), text-lg (20px)
- **Body Text**: text-base (16px), text-sm (14px)
- **Emphasis**: font-semibold for headings, font-medium for important content

### Layout System
**Spacing Units**: Consistent use of Tailwind units 2, 4, 6, and 8
- `p-4` for card padding
- `m-6` for section spacing
- `gap-4` for component spacing
- `h-8` for button heights

## Component Library

### Navigation
- **Bottom Tab Bar**: Fixed navigation with 4-5 primary sections per role
- **Role Indicator**: Subtle badge showing current user type
- **Quick Actions**: Floating action button for primary tasks

### Gamification Elements
- **Point Display**: Large, prominent counter in header (850 points format)
- **Progress Bars**: Circular progress for levels, linear for daily goals
- **Achievement Cards**: Compact cards with icons and point values
- **Leaderboard**: Simple list format with rankings and avatars

### Interactive Components
- **QR Scanner**: Full-screen camera interface with scanning guides
- **Map Interface**: Interactive map with cluster markers for bins/routes
- **Task Cards**: Swipe-enabled cards for field staff workflows
- **Report Forms**: Step-by-step wizard format for issue reporting

### Role-Specific Interfaces

**Citizens**: Dashboard-focused with prominent point display, upcoming pickups, quick scan access, and tips section

**Field Staff**: Task-oriented with route maps, bin status indicators, high-contrast mode for outdoor visibility, and one-handed operation priority

**Admin**: Data-dense with collapsible sections, filterable lists, analytics cards, and system status indicators

## Mobile-First Considerations
- **Touch Targets**: Minimum 44px height for all interactive elements
- **Thumb Navigation**: Bottom-heavy interface design
- **Offline Capability**: Clear offline state indicators
- **Loading States**: Skeleton screens and progress indicators
- **Gesture Support**: Swipe actions for common tasks

## Images
- **No large hero images** - prioritize functional interface over marketing visuals
- **Icon System**: Use Heroicons for consistency across all interfaces
- **Avatar Placeholders**: Circular user profile images (40px standard)
- **Achievement Icons**: Colorful badge-style icons for gamification
- **Map Markers**: Custom waste bin and truck icons for location tracking

The design prioritizes functionality and accessibility while maintaining engaging gamification elements that encourage user participation in the waste management ecosystem.